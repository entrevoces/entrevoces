# Entre Voces — three additive game experiments

These are original, mobile-first arcade experiments. They extend the existing `entrevoces` hub, game runtime, knowledge snapshot, and `EngineClient`; they do not replace the existing suite. Their core arcade loops remain static and offline-friendly. The optional *spoken sight-transfer* extension uses a separate local HTTP gateway, which calls Meta models only with microphone consent.

| Game | Main physical interaction | Learning component supported |
| --- | --- | --- |
| Río de Palabras | Select neighboring bilingual equivalences; all on-board matches resolve in deterministic cascading waves | Supported recognition of reviewed bilingual medical/legal terminology |
| Última Parada | Route a moving train to the correct translated platform; earn and spend time-limited brake signals | Time-constrained bilingual term recognition and attention switching |
| Pulso de Luz | Aim and bank a glowing projectile into a translation target with physically matched trajectory previews | Bilingual term recognition with spatial planning and trajectory control |

Players can switch between Oregon-rooted medical/legal terms and English→Spanish or English→Mandarin using source-linked terminology already present in the compiled curriculum. The game controls do not require typing. Each game offers finite sessions, retry, pause, keyboard access, score/combo feedback, gentle/brisk pacing and device-local progress. Difficulty reacts conservatively to an existing evidence threshold; an older learner is not automatically given an easier task based on demographics.

## Learning integrity

- The new `engine-core/choice-assessment.js` grades **only explicit semantic choices** against sourced, unambiguous, language-specific candidates, without conflating games' motor outcomes with learning. Source and target directions are recorded accurately even when a bilingual tile-pair is selected in reverse order.
- `EngineClient` records the concept, domain, explicit language direction, answer modality, activity type and support status. Cascades, missed trains, projectile collisions, motor timing and strategic points do not create learner evidence.
- The evidence stage is **2**, activity type `bilingual`, confidence **0.70**, response modality `touch` or `keyboard`, and assessment method `visible-term-choice`. This represents supported recognition/selection, not independent spoken production, conversation management, or professional interpreter certification.
- The shared engine validates the limited claims of visual term choices and rejects any attempt to label touch responses as spoken interpreting proficiency. Older evidence without optional modality labels stays readable.
- Hint use is recorded as assistance. The learner model already discounts such attempts, and the game-difficulty policy requires a minimum of independent, confident observations before promotion. The same learner state is used to favor due, weak and unseen concepts when choosing new source terms; repeated easy wins are not the only replay objective.
- Labels and answer keys come only from the existing compiled knowledge snapshot. The game filters out unsourced, inferred and ambiguous identical-label alternatives. This demo does not create legal advice, medical instructions, fabricated bilingual phrases, or live patient/client scenarios.
- Different terms can have context-sensitive equivalents; the bundled content is a starting corpus rather than an independently adjudicated reference standard. The engine does not claim professional certification.

## Opt-in spoken practice, powered by Meta open-weight models on Modal

All three games now have a **Speak** control (`V` with a keyboard). It opens a large-button, scrollable voice panel for a short **fictional and source-backed** medical/legal sentence. The player can hear that source in the device's own speech synthesizer, then record their interpretation. The **Reverse languages** button supports **English ⇄ Spanish** and **English ⇄ Mandarin**, so Spanish-speaking trainees can practice Spanish → English as well as English → Spanish. Its source remains visible, so this assesses supported **spoken sight transfer (stage 7)**, not blind consecutive or simultaneous performance (stage 8).

When enabled, the browser converts microphone PCM to a 16 kHz, mono, signed 16-bit WAV, up to 30 seconds. The opt-in recording goes **directly from the static GitHub Pages game to a Modal HTTP endpoint**. Modal validates format, approved task identity and the access code, then runs **Meta SeamlessM4T v2 Large** for same-language speech recognition and **Meta Llama 3.1 8B Instruct** for source-grounded meaning-unit assessment. The response highlights preserved, changed, omitted and uncertain source meanings with exact excerpts. Invalid, contradictory and low-confidence model results become **indeterminate**, which earns no learning evidence. A learner can dispute an ASR error by recording again. No raw audio or transcript is written into browser progress or the application's server logs. Do not submit any real patient or client information.

An unassisted game term choice remains stage-2 evidence. A supported spoken assessment records **provisional stage-7 practice** separately, with `visible-source` and `ai-provisional` assistance flags that prevent it from masquerading as independent professional readiness. Errors in aiming, cascades or transit scheduling are still never treated as mistranslation. A faithful spoken response awards two temporary **arcade power moves**; retries of the same concept during one run cannot farm those rewards. Neither power-ups nor arcade points grant learning mastery.

### Deploy (GitHub Pages + Modal)

1. Read [`services/modal-spoken/README.md`](../../services/modal-spoken/README.md) for Modal account setup, gated Llama access, noncommercial speech model license, GPU cost, authentication code and deployment verification.
2. From this repository root, run `npm run build`, `npm run modal:check`, then `modal deploy services/modal-spoken/modal_app.py` in your own configured Modal account.
3. Set GitHub Actions **repository variable** `EV_SPOKEN_API_URL` to the resulting credential-free Modal HTTPS endpoint. The Pages workflow publishes only `dist/`, including a URL-only `spoken-config.json`.
4. For static-only play, run `npm run build && npm run hub`; all three games still work with voice unavailable until a Modal URL is configured.

The Meta models run on isolated Modal GPU containers, not inside the browser or GitHub Pages. Their first request has cold-start/model-download latency and incurs GPU cost; the demo code plus limited scaling guard against casual abuse. **SeamlessM4T v2 Large is CC-BY-NC-4.0**: this setup is intended only for eligible noncommercial demonstration. The game's source playback uses the device's speech synthesis, not a generated Meta voice. Human validation is still necessary before relying on assessment outcomes.

### Test coverage

- `tests/spoken-gateway.test.js`: retains local-gateway regression coverage and checks the new 16 kHz browser encoder and HTTPS-only Modal URL normalizer.
- `tests/test_modal_spoken.py`: tests actual Modal-side source task eligibility, duration/format checks, source-quote validation, Mandarin coverage and handling of untrusted learner transcripts, without GPU fees.
- `tests/arcade-evaluation.test.js`: extended to match pulse flight with its visual trajectory forecast and validate persisted brake/voice power state.
- `tests/arcade-smoke.test.js`: completes the three full arcade runs on virtual phone viewports with or without an optional gateway.
- `npm run spoken:calibrate -- --dry-run` previews ten synthetic, source-linked adversarial transcripts across directions, Spanish/Mandarin, medical/legal, timing, negation and language mismatch. With `EV_SPOKEN_API_URL` and a separately supplied `EV_DEMO_ACCESS_CODE`, `npm run spoken:calibrate` invokes the same Modal Llama assessment model (up to 10 billable assessments). **This is a smoke calibration, not a substitute for interpreter-labelled gold data.** `--limit 2` bounds experiment cost.

**Live Modal GPU audio transcription and medical/legal semantic accuracy remain unverified** until Modal credentials, model license approvals, GPU billing and human-labelled test recordings are available. The recorded evaluation scores are teaching signals, not credentialing.

## Integration

- Manifest: `knowledge/game-suite/manifest.json`.
- Source: `apps/games/{rio-de-palabras,ultima-parada,pulso-de-luz}/index.html` and shared `apps/games/_shared/game.js`.
- Build: `npm run build`, which includes the maintained shared `packages/game-runtime` modules and copies three game directories to `dist/games/`.
- Smoke test: `node --test tests/arcade-smoke.test.js` drives full successful sessions through all three games at 320px and 390px virtual viewports, checking scores, physical collisions, semantic evidence, completion and restart with an instrumented canvas.
- Evaluation and fairness test: `node --test tests/arcade-evaluation.test.js` validates thousands of seeded levels, known answer keys, ambiguity rejection, stage restrictions, idempotent evidence, strict persistence, and reachable targets.

## Status and next review

These are **experimental playable vertical slices**, not fully assessed or professionally validated training. They need real-device visual QA, demographic usability testing, deeper context-sensitive medical/legal distinctions, and real audio trials of the new provisional spoken layer. The game implementations cannot independently validate bilingual translations without subject-matter review. Four design critiques of a superseded set of concepts identified learning-evidence and puzzle-fairness pitfalls; the shared safety constraints were applied here, but these new game designs have not received the same human usability review.
