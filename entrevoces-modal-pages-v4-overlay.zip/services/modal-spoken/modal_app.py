"""Deploy: npm run build && modal deploy services/modal-spoken/modal_app.py

GitHub Pages serves every game and its knowledge UI. Modal serves ONLY the
opt-in audio transcription + provisional semantic assessment. Models are Meta
open-weight checkpoints on isolated Modal GPUs, not Meta hosted Muse APIs.
"""

import os

import modal

from pathlib import Path

app = modal.App("entre-voces-spoken")

# Resolve data from the repository regardless of the caller's working directory.
REPO = Path(__file__).resolve().parents[2]
CORPUS = REPO / "dist" / "curriculum.json"
if not CORPUS.exists():
    raise RuntimeError("Run 'npm run build' before deploying the Modal service.")

api_image = (
    modal.Image.debian_slim(python_version="3.11")
    .pip_install("fastapi==0.115.8")
    .add_local_file(str(REPO / "services/modal-spoken/core.py"), "/srv/core.py")
    .add_local_file(str(CORPUS), "/srv/curriculum.json")
)
gpu_image = (
    modal.Image.debian_slim(python_version="3.11")
    .pip_install(
        "torch==2.5.1", "transformers==4.48.3", "accelerate==1.3.0",
        "numpy==1.26.4", "sentencepiece==0.2.0", "protobuf==5.29.3",
    )
)
speech_cache = modal.Volume.from_name("entre-voces-seamless-cache", create_if_missing=True)
meaning_cache = modal.Volume.from_name("entre-voces-llama-cache", create_if_missing=True)


@app.cls(image=gpu_image, gpu="A10", timeout=240, max_containers=1,
         scaledown_window=60, volumes={"/root/.cache/huggingface": speech_cache})
class Speech:
    @modal.enter()
    def load(self):
        from transformers import AutoProcessor, SeamlessM4Tv2Model
        import torch

        self.processor = AutoProcessor.from_pretrained("facebook/seamless-m4t-v2-large")
        self.model = SeamlessM4Tv2Model.from_pretrained(
            "facebook/seamless-m4t-v2-large", torch_dtype=torch.float16,
            low_cpu_mem_usage=True,
        ).to("cuda").eval()

    @modal.method()
    def transcribe(self, pcm: bytes, language: str) -> dict:
        import numpy as np
        import torch

        codes = {"en": "eng", "es": "spa", "zh": "cmn"}
        if language not in codes or len(pcm) > 960_000:
            raise ValueError("Invalid speech request")
        samples = np.frombuffer(pcm, dtype="<i2").astype(np.float32) / 32768.0
        inputs = self.processor(audio=samples, sampling_rate=16_000, return_tensors="pt").to("cuda")
        with torch.inference_mode():
            # Same-language text output = transcription; do not replace it with
            # model-generated cross-language translation for grading.
            tokens = self.model.generate(**inputs, tgt_lang=codes[language], generate_speech=False)
            # Chinese is *not* officially listed among Llama 3.1's supported
            # languages. Give the evaluator an independently generated English
            # diagnostic pivot, without treating it as reviewed ground truth.
            pivot_tokens = self.model.generate(**inputs, tgt_lang="eng", generate_speech=False) if language == "zh" else None
        transcript = self.processor.decode(tokens[0].tolist()[0], skip_special_tokens=True).strip()[:2200]
        backtranslation = (self.processor.decode(pivot_tokens[0].tolist()[0], skip_special_tokens=True).strip()[:2200]
                           if pivot_tokens is not None else "")
        return {"transcript": transcript, "englishBacktranslation": backtranslation}


@app.cls(image=gpu_image, gpu="A10", timeout=240, max_containers=1,
         scaledown_window=60, volumes={"/root/.cache/huggingface": meaning_cache},
         secrets=[modal.Secret.from_name("entre-voces-hf-access")])
class Meaning:
    @modal.enter()
    def load(self):
        from transformers import AutoModelForCausalLM, AutoTokenizer
        import torch

        checkpoint = "meta-llama/Llama-3.1-8B-Instruct"
        token = os.environ.get("HF_TOKEN")
        if not token:
            raise RuntimeError("HF_TOKEN is required for the gated Meta Llama model.")
        self.tokenizer = AutoTokenizer.from_pretrained(checkpoint, token=token)
        self.model = AutoModelForCausalLM.from_pretrained(
            checkpoint, token=token, torch_dtype=torch.float16,
            low_cpu_mem_usage=True,
        ).to("cuda").eval()

    @modal.method()
    def assess(self, messages: list) -> str:
        import torch

        encoded = self.tokenizer.apply_chat_template(
            messages, add_generation_prompt=True, tokenize=True, return_tensors="pt",
        ).to("cuda")
        if encoded.shape[1] > 1800:
            raise ValueError("Assessment prompt is too large")
        with torch.inference_mode():
            result = self.model.generate(
                encoded, max_new_tokens=900, do_sample=False,
                pad_token_id=self.tokenizer.eos_token_id,
            )
        return self.tokenizer.decode(result[0][encoded.shape[1]:], skip_special_tokens=True)


@app.function(image=api_image, timeout=320, max_containers=1,
              secrets=[modal.Secret.from_name("entre-voces-demo-access")])
@modal.concurrent(max_inputs=4)
@modal.asgi_app()
def web():
    import hmac
    import json
    import sys
    import time

    from collections import deque
    from fastapi import FastAPI, HTTPException, Request
    from fastapi.middleware.cors import CORSMiddleware

    sys.path.insert(0, "/srv")
    from core import (MODEL_MEANING, MODEL_SPEECH, MAX_WAV_BYTES, approved_task,
                      assessment_prompt, indeterminate, parse_assessment,
                      task_by_id, validate_audio)

    corpus = json.loads(Path("/srv/curriculum.json").read_text(encoding="utf-8"))["knowledge"]
    code = os.environ.get("EV_DEMO_ACCESS_CODE", "")
    if len(code) < 12:
        raise RuntimeError("Set EV_DEMO_ACCESS_CODE (12+ characters) in the Modal demo-access secret to protect GPU costs.")
    allowed_origins = [v.strip() for v in os.environ.get(
        "EV_ALLOWED_ORIGINS", "https://entrevoces.github.io,http://127.0.0.1:8014,http://localhost:8014"
    ).split(",") if v.strip()]
    web_app = FastAPI(title="Entre Voces — Meta open-weight voice practice", docs_url=None, redoc_url=None)
    web_app.add_middleware(
        CORSMiddleware, allow_origins=allowed_origins, allow_methods=["GET", "POST"],
        allow_headers=["Content-Type", "X-EV-Access-Code"], max_age=600,
    )
    requests = deque()

    @web_app.get("/api/spoken/health")
    async def health():
        return {
            "enabled": True, "accessRequired": bool(code),
            "speechModel": MODEL_SPEECH, "assessmentModel": MODEL_MEANING,
            "maxSeconds": 30, "liveStreaming": False,
        }

    @web_app.get("/api/spoken/task")
    async def task(domain: str = "", lang: str = "", conceptId: str = "", direction: str = "forward"):
        approved = approved_task(corpus, domain, lang, conceptId, direction)
        if not approved:
            raise HTTPException(404, "No sourced speaking scenario for that concept.")
        return {key: value for key, value in approved.items() if key != "referenceText"}

    def require_access(request):
        if code and not hmac.compare_digest(request.headers.get("X-EV-Access-Code", ""), code):
            raise HTTPException(401, "Enter the demo access code to use the voice service.")

    def budget_check():
        now = time.monotonic()
        while requests and now - requests[0] > 60:
            requests.popleft()
        if len(requests) >= 12:
            raise HTTPException(429, "Voice practice is busy. Please retry in one minute.")
        requests.append(now)

    def check_content_length(request, max_bytes):
        try:
            length = int(request.headers.get("content-length", "0"))
        except ValueError:
            raise HTTPException(400, "Invalid Content-Length header.") from None
        if length < 0 or length > max_bytes:
            raise HTTPException(413, "Request body too large.")

    @web_app.post("/api/spoken/assess")
    async def assess(request: Request, taskId: str = ""):
        require_access(request)
        approved = task_by_id(corpus, taskId)
        if not approved:
            raise HTTPException(400, "Unknown approved speaking task.")
        if request.headers.get("content-type", "").split(";")[0].strip() != "audio/wav":
            raise HTTPException(415, "Send mono 16-bit PCM WAV audio at 16 kHz.")
        check_content_length(request, MAX_WAV_BYTES)
        data = bytearray()
        async for chunk in request.stream():
            data.extend(chunk)
            if len(data) > MAX_WAV_BYTES:
                raise HTTPException(413, "Recording too large.")
        pcm = validate_audio(bytes(data))
        if pcm is None:
            raise HTTPException(422, "Invalid recording. Send up to 30 seconds of 16 kHz mono PCM WAV.")
        # Single-container best-effort demo quota; not a distributed global
        # limiter. The non-embedded access code is the primary cost guard.
        budget_check()
        try:
            recognized = await Speech().transcribe.remote.aio(pcm, approved["targetLanguage"])
            transcript = recognized["transcript"]
            if not transcript:
                assessment = indeterminate("No clear speech detected. Try recording again.")
            else:
                raw = await Meaning().assess.remote.aio(assessment_prompt(
                    approved, transcript, recognized.get("englishBacktranslation", "")
                ))
                assessment = parse_assessment(raw, approved["sourceText"], transcript)
        except Exception:
            # No transcript/audio in logs, errors, or public responses.
            raise HTTPException(503, "Voice models are warming up or temporarily unavailable. Please retry.") from None
        return {
            "taskId": taskId, "transcript": transcript, "assessment": assessment,
            "stage": 7,
            "usableEvidence": assessment["verdict"] != "indeterminate" and assessment["confidence"] >= .8,
            "sourceIds": approved["sourceIds"],
        }

    @web_app.post("/api/spoken/calibrate")
    async def calibrate(request: Request, taskId: str = ""):
        """Authenticated, optional TEXT-only synthetic grading comparison."""
        require_access(request)
        approved = task_by_id(corpus, taskId)
        if not approved:
            raise HTTPException(400, "Unknown approved speaking task.")
        if request.headers.get("content-type", "").split(";")[0].strip() != "application/json":
            raise HTTPException(415, "Send JSON transcript data.")
        check_content_length(request, 5_000)
        body = await request.body()
        if len(body) > 5_000:
            raise HTTPException(413, "Calibration item too large.")
        try:
            payload = json.loads(body)
            transcript = payload["transcript"]
        except (ValueError, TypeError, KeyError):
            raise HTTPException(400, "Missing calibration transcript.") from None
        if not isinstance(transcript, str) or not 1 <= len(transcript) <= 2200:
            raise HTTPException(422, "Invalid calibration transcript.")
        budget_check()
        try:
            raw = await Meaning().assess.remote.aio(assessment_prompt(approved, transcript))
            assessment = parse_assessment(raw, approved["sourceText"], transcript)
        except Exception:
            raise HTTPException(503, "Meaning model unavailable. Please retry.") from None
        return {"taskId": taskId, "assessment": assessment, "humanValidated": False}

    return web_app
